dso-modlist
===========

Práctica de Diseño de Sistemas Operativos. Implementación de un módulo lista enlazada. Uso de las listas enlazadas del kernel.
